This directory contains some deployment manager configuration files that can be used to setup
GCP for Kubeflow.

These deployment configuration files are intended to be used with kfctl.